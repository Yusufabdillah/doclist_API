create
  definer = root@localhost procedure sp_utlperusahaanakses(IN KEY_CALL varchar(20), IN KOLOM varchar(40),
                                                           IN IN_idGrup int, IN IN_idPerusahaan int)
BEGIN

  CASE KEY_CALL
    WHEN 'getAll' THEN
      SELECT m1.idGrup, m2.idPerusahaan, m2.idKecamatan, m2.singkatanPerusahaan, m2.namaPerusahaan, m2.lokasiPerusahaan
      FROM tbl_utlperusahaanakses AS m1 INNER JOIN tbl_mstperusahaan AS m2 ON m1.idPerusahaan = m2.idPerusahaan;

    WHEN 'getDataSite' THEN
      SELECT m1.idGrup, m2.idPerusahaan, m2.idKecamatan, m2.singkatanPerusahaan, m2.namaPerusahaan, m2.lokasiPerusahaan
      FROM tbl_utlperusahaanakses AS m1 INNER JOIN tbl_mstperusahaan AS m2 ON m1.idPerusahaan = m2.idPerusahaan
      WHERE m1.idGrup = IN_idGrup;

    WHEN 'getViewSite' THEN
      SELECT m1.idGrup, m2.idPerusahaan, m2.idKecamatan, m2.singkatanPerusahaan, m2.namaPerusahaan, m2.lokasiPerusahaan, 1 AS Atc
      FROM tbl_utlperusahaanakses AS m1 INNER JOIN tbl_mstperusahaan AS m2 ON m1.idPerusahaan = m2.idPerusahaan
      WHERE m1.idGrup = IN_idGrup
      UNION ALL SELECT NULL AS idGrup, idPerusahaan, idKecamatan, singkatanPerusahaan, namaPerusahaan, lokasiPerusahaan, 0 AS Atc
      FROM tbl_mstperusahaan WHERE idPerusahaan NOT IN (SELECT idPerusahaan FROM tbl_utlperusahaanakses WHERE (idGrup = IN_idGrup))
      ORDER BY idPerusahaan ASC;

    WHEN 'create' THEN
      INSERT INTO tbl_utlperusahaanakses (idGrup, idPerusahaan) VALUES (IN_idGrup, IN_idPerusahaan);

    WHEN 'delete' THEN
      DELETE FROM tbl_utlperusahaanakses WHERE idGrup = IN_idGrup;

  END CASE ;

END;

