create definer = root@localhost view vw_mstdepartemen as
select `db_permit_rsup`.`tbl_mstdepartemen`.`﻿idDepartemen`       AS `idDepartemen`,
       `db_permit_rsup`.`tbl_mstdepartemen`.`idPerusahaan`        AS `idPerusahaan`,
       `db_permit_rsup`.`tbl_mstperusahaan`.`namaPerusahaan`      AS `namaPerusahaan`,
       `db_permit_rsup`.`tbl_mstperusahaan`.`lokasiPerusahaan`    AS `lokasiPerusahaan`,
       `db_permit_rsup`.`tbl_mstperusahaan`.`singkatanPerusahaan` AS `singkatanPerusahaan`,
       `db_permit_rsup`.`tbl_mstdepartemen`.`singkatanDepartemen` AS `singkatanDepartemen`,
       `db_permit_rsup`.`tbl_mstdepartemen`.`namaDepartemen`      AS `namaDepartemen`,
       `db_permit_rsup`.`tbl_mstdepartemen`.`statusDepartemen`    AS `statusDepartemen`,
       `db_permit_rsup`.`tbl_mstdepartemen`.`createdBy`           AS `createdBy`,
       `db_permit_rsup`.`tbl_mstdepartemen`.`createdDate`         AS `createdDate`,
       `db_permit_rsup`.`tbl_mstdepartemen`.`updatedBy`           AS `updatedBy`,
       `db_permit_rsup`.`tbl_mstdepartemen`.`updatedDate`         AS `updatedDate`
from (`db_permit_rsup`.`tbl_mstdepartemen`
       left join `db_permit_rsup`.`tbl_mstperusahaan` on ((`db_permit_rsup`.`tbl_mstdepartemen`.`idPerusahaan` =
                                                           `db_permit_rsup`.`tbl_mstperusahaan`.`idPerusahaan`)));

