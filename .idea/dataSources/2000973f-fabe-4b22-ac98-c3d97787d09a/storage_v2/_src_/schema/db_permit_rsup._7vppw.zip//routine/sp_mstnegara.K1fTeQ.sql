create
  definer = root@localhost procedure sp_mstnegara(IN KEY_CALL varchar(20), IN KOLOM varchar(40),
                                                  IN VALUE_DATA varchar(100), IN SINGKATAN varchar(30),
                                                  IN CREATED_BY varchar(50), IN UPDATED_BY varchar(50), IN PK int)
BEGIN

  CASE KEY_CALL
    WHEN 'getAll' THEN
    SELECT * FROM tbl_mstnegara;

    WHEN 'getData' THEN
      CASE KOLOM
        WHEN 'idNegara' THEN
        SELECT * FROM tbl_mstnegara WHERE idNegara = VALUE_DATA;

        WHEN 'namaNegara' THEN
        SELECT * FROM tbl_mstnegara WHERE namaNegara LIKE VALUE_DATA;
        END CASE ;

    WHEN 'create' THEN
      INSERT INTO tbl_mstnegara (namaNegara, singkatanNegara, createdBy) VALUES (VALUE_DATA, SINGKATAN, CREATED_BY);

    WHEN 'update' THEN
      UPDATE tbl_mstnegara SET namaNegara = VALUE_DATA, singkatanNegara = SINGKATAN, updatedBy = UPDATED_BY, updatedDate = now() WHERE idNegara = PK;

    WHEN 'delete' THEN
      DELETE FROM tbl_mstnegara WHERE idNegara = PK;

  END CASE ;

END;

