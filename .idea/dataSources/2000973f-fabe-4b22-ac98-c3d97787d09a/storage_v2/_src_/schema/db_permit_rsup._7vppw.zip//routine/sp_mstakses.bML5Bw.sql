create
  definer = root@localhost procedure sp_mstakses(IN KEY_CALL varchar(20), IN KOLOM varchar(40), IN IN_idAkses int,
                                                 IN IN_namaAkses varchar(255), IN CREATED_BY varchar(50),
                                                 IN UPDATED_BY varchar(50))
BEGIN

  CASE KEY_CALL
    WHEN 'getAll' THEN
    SELECT * FROM tbl_mstakses;

    WHEN 'getData' THEN
      CASE KOLOM
        WHEN 'idAkses' THEN
        SELECT * FROM tbl_mstakses WHERE idAkses = IN_idAkses;

        WHEN 'namaAkses' THEN
        SELECT * FROM tbl_mstakses WHERE namaAkses LIKE IN_namaAkses;
        END CASE ;

    WHEN 'create' THEN
      INSERT INTO tbl_mstakses (namaAkses, createdBy, createdDate)
                             VALUES (IN_namaAkses, CREATED_BY, NOW());

    WHEN 'update' THEN
      UPDATE tbl_mstakses SET
                                   namaAkses = IN_namaAkses,
                                   updatedBy = UPDATED_BY,
                                   updatedDate = now()
      WHERE idAkses = IN_idAkses;

    WHEN 'delete' THEN
      DELETE FROM tbl_mstakses WHERE idAkses = IN_idAkses;

  END CASE ;

END;

