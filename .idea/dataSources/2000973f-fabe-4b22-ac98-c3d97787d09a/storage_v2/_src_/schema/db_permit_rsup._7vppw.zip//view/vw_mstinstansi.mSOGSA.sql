create definer = root@localhost view vw_mstinstansi as
select `db_permit_rsup`.`tbl_mstinstansi`.`idInstansi`      AS `idInstansi`,
       `db_permit_rsup`.`tbl_mstinstansi`.`idKota`          AS `idKota`,
       `db_permit_rsup`.`vw_mstkota`.`namaKota`             AS `namaKota`,
       `db_permit_rsup`.`vw_mstkota`.`idProvinsi`           AS `idProvinsi`,
       `db_permit_rsup`.`vw_mstkota`.`namaProvinsi`         AS `namaProvinsi`,
       `db_permit_rsup`.`vw_mstkota`.`idNegara`             AS `idNegara`,
       `db_permit_rsup`.`vw_mstkota`.`namaNegara`           AS `namaNegara`,
       `db_permit_rsup`.`tbl_mstinstansi`.`namaInstansi`    AS `namaInstansi`,
       `db_permit_rsup`.`tbl_mstinstansi`.`alamatInstansi`  AS `alamatInstansi`,
       `db_permit_rsup`.`tbl_mstinstansi`.`jbt_kplInstansi` AS `jbt_kplInstansi`,
       `db_permit_rsup`.`tbl_mstinstansi`.`kepalaInstansi`  AS `kepalaInstansi`,
       `db_permit_rsup`.`tbl_mstinstansi`.`createdBy`       AS `createdBy`,
       `db_permit_rsup`.`tbl_mstinstansi`.`createdDate`     AS `createdDate`,
       `db_permit_rsup`.`tbl_mstinstansi`.`updatedBy`       AS `updatedBy`,
       `db_permit_rsup`.`tbl_mstinstansi`.`updatedDate`     AS `updatedDate`
from (`db_permit_rsup`.`tbl_mstinstansi`
       left join `db_permit_rsup`.`vw_mstkota`
                 on ((`db_permit_rsup`.`tbl_mstinstansi`.`idKota` = `db_permit_rsup`.`vw_mstkota`.`idKota`)));

