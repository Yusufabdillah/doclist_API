create definer = root@localhost view vw_refaudit as
select `db_permit_rsup`.`tbl_refaudit`.`idRef_audit` AS `idRef_audit`,
       `db_permit_rsup`.`tbl_refaudit`.`idAudit`     AS `idAudit`,
       `db_permit_rsup`.`tbl_mstaudit`.`namaAudit`   AS `namaAudit`,
       `db_permit_rsup`.`tbl_refaudit`.`idDokumen`   AS `idDokumen`,
       `vw_mstdokumen`.`judulDokumen`                AS `judulDokumen`,
       `vw_mstdokumen`.`nomorDokumen`                AS `nomorDokumen`,
       `vw_mstdokumen`.`casenumberDokumen`           AS `casenumberDokumen`,
       `vw_mstdokumen`.`idDepartemen`                AS `idDepartemen`,
       `vw_mstdokumen`.`namaDepartemen`              AS `namaDepartemen`,
       `vw_mstdokumen`.`singkatanDepartemen`         AS `singkatanDepartemen`,
       `vw_mstdokumen`.`tgl_terbitDokumen`           AS `tgl_terbitDokumen`,
       `vw_mstdokumen`.`expired_unlimitedDokumen`    AS `expired_unlimitedDokumen`,
       `vw_mstdokumen`.`tgl_habisDokumen`            AS `tgl_habisDokumen`,
       `db_permit_rsup`.`tbl_refaudit`.`createdBy`   AS `createdBy`,
       `db_permit_rsup`.`tbl_refaudit`.`createdDate` AS `createdDate`
from ((`db_permit_rsup`.`tbl_refaudit` left join `db_permit_rsup`.`tbl_mstaudit` on ((
    `db_permit_rsup`.`tbl_mstaudit`.`idAudit` = `db_permit_rsup`.`tbl_refaudit`.`idAudit`)))
       left join `db_permit_rsup`.`vw_mstdokumen`
                 on ((`vw_mstdokumen`.`idDokumen` = `db_permit_rsup`.`tbl_refaudit`.`idDokumen`)));

