create
  definer = root@localhost procedure sp_mstperusahaan(IN KEY_CALL varchar(20), IN KOLOM varchar(40),
                                                      IN IN_idPerusahaan int, IN IN_idKecamatan int,
                                                      IN IN_namaPerusahaan varchar(255),
                                                      IN IN_singkatanPerusahaan varchar(20),
                                                      IN IN_lokasiPerusahaan varchar(255), IN CREATED_BY varchar(50),
                                                      IN UPDATED_BY varchar(50))
BEGIN

  CASE KEY_CALL
    WHEN 'getAll' THEN
    SELECT * FROM vw_mstperusahaan;

    WHEN 'getData' THEN
      CASE KOLOM
        WHEN 'idPerusahaan' THEN
        SELECT * FROM vw_mstperusahaan WHERE idPerusahaan = IN_idPerusahaan;

        WHEN 'namaPerusahaan' THEN
        SELECT * FROM vw_mstperusahaan WHERE namaPerusahaan LIKE IN_namaPerusahaan;
        END CASE ;

    WHEN 'create' THEN
      INSERT INTO tbl_mstperusahaan (idKecamatan, namaPerusahaan, singkatanPerusahaan, lokasiPerusahaan, createdBy, createdDate) VALUES (IN_idKecamatan, IN_namaPerusahaan, IN_singkatanPerusahaan, IN_lokasiPerusahaan, CREATED_BY, now());

    WHEN 'update' THEN
      UPDATE tbl_mstperusahaan SET idKecamatan = IN_idKecamatan, namaPerusahaan = IN_namaPerusahaan, singkatanPerusahaan = IN_singkatanPerusahaan, lokasiPerusahaan = IN_lokasiPerusahaan, updatedBy = UPDATED_BY, updatedDate = now() WHERE idPerusahaan = IN_idPerusahaan;

    WHEN 'delete' THEN
      DELETE FROM tbl_mstperusahaan WHERE idPerusahaan = IN_idPerusahaan;

  END CASE ;

END;

