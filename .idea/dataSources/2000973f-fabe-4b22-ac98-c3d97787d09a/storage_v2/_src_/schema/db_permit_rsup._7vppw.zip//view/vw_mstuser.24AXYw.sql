create definer = root@localhost view vw_mstuser as
select `db_permit_rsup`.`tbl_mstuser`.`idUser`                    AS `idUser`,
       `db_permit_rsup`.`tbl_mstuser`.`idPerusahaan`              AS `idPerusahaan`,
       `db_permit_rsup`.`tbl_mstperusahaan`.`namaPerusahaan`      AS `namaPerusahaan`,
       `db_permit_rsup`.`tbl_mstperusahaan`.`lokasiPerusahaan`    AS `lokasiPerusahaan`,
       `db_permit_rsup`.`tbl_mstperusahaan`.`singkatanPerusahaan` AS `singkatanPerusahaan`,
       `db_permit_rsup`.`tbl_mstuser`.`idDepartemen`              AS `idDepartemen`,
       `db_permit_rsup`.`tbl_mstdepartemen`.`namaDepartemen`      AS `namaDepartemen`,
       `db_permit_rsup`.`tbl_mstdepartemen`.`singkatanDepartemen` AS `singkatanDepartemen`,
       `db_permit_rsup`.`tbl_mstdepartemen`.`statusDepartemen`    AS `statusDepartemen`,
       `db_permit_rsup`.`tbl_mstuser`.`idJabatan`                 AS `idJabatan`,
       `db_permit_rsup`.`tbl_mstjabatan`.`namaJabatan`            AS `namaJabatan`,
       `db_permit_rsup`.`tbl_mstjabatan`.`singkatanJabatan`       AS `singkatanJabatan`,
       `db_permit_rsup`.`tbl_mstuser`.`idGrup`                    AS `idGrup`,
       `vw_mstgrupuser`.`namaGrup`                                AS `namaGrup`,
       `vw_mstgrupuser`.`namaPerusahaan`                          AS `Grup_namaPerusahaan`,
       `vw_mstgrupuser`.`lokasiPerusahaan`                        AS `Grup_lokasiPerusahaan`,
       `vw_mstgrupuser`.`idAkses`                                 AS `idAkses`,
       `vw_mstgrupuser`.`namaAkses`                               AS `namaAkses`,
       `db_permit_rsup`.`tbl_mstuser`.`namaUser`                  AS `namaUser`,
       `db_permit_rsup`.`tbl_mstuser`.`statusAPI`                 AS `statusAPI`,
       `db_permit_rsup`.`tbl_mstuser`.`statusPIC`                 AS `statusPIC`,
       `db_permit_rsup`.`tbl_mstuser`.`passUser`                  AS `passUser`,
       `db_permit_rsup`.`tbl_mstuser`.`statusUser`                AS `statusUser`,
       `db_permit_rsup`.`tbl_mstuser`.`telpUser`                  AS `telpUser`,
       `db_permit_rsup`.`tbl_mstuser`.`createdBy`                 AS `createdBy`,
       `db_permit_rsup`.`tbl_mstuser`.`createdDate`               AS `createdDate`,
       `db_permit_rsup`.`tbl_mstuser`.`updatedBy`                 AS `updatedBy`,
       `db_permit_rsup`.`tbl_mstuser`.`updatedDate`               AS `updatedDate`
from ((((`db_permit_rsup`.`tbl_mstuser` left join `db_permit_rsup`.`tbl_mstperusahaan` on ((
    `db_permit_rsup`.`tbl_mstuser`.`idPerusahaan` =
    `db_permit_rsup`.`tbl_mstperusahaan`.`idPerusahaan`))) left join `db_permit_rsup`.`tbl_mstdepartemen` on ((
    `db_permit_rsup`.`tbl_mstuser`.`idDepartemen` =
    `db_permit_rsup`.`tbl_mstdepartemen`.`﻿idDepartemen`))) left join `db_permit_rsup`.`tbl_mstjabatan` on ((
    `db_permit_rsup`.`tbl_mstuser`.`idJabatan` = `db_permit_rsup`.`tbl_mstjabatan`.`idJabatan`)))
       left join `db_permit_rsup`.`vw_mstgrupuser`
                 on ((`db_permit_rsup`.`tbl_mstuser`.`idGrup` = `vw_mstgrupuser`.`idGrup`)))
order by `db_permit_rsup`.`tbl_mstuser`.`idUser`;

