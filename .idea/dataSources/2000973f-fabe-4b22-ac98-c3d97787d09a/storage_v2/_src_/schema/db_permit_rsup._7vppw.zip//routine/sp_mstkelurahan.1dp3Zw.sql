create
  definer = root@localhost procedure sp_mstkelurahan(IN KEY_CALL varchar(20), IN KOLOM varchar(40),
                                                     IN IN_idKelurahan int, IN IN_idKecamatan int,
                                                     IN IN_namaKelurahan varchar(100), IN CREATED_BY varchar(50),
                                                     IN UPDATED_BY varchar(50))
BEGIN

  CASE KEY_CALL
    WHEN 'getAll' THEN
    SELECT * FROM vw_mstkelurahan;

    WHEN 'getData' THEN
      CASE KOLOM
        WHEN 'idKelurahan' THEN
        SELECT * FROM vw_mstkelurahan WHERE idKelurahan = IN_idKelurahan;
        
        WHEN 'idKecamatan' THEN
        SELECT * FROM vw_mstkelurahan WHERE idKecamatan = IN_idKecamatan;

        WHEN 'namaKelurahan' THEN
        SELECT * FROM vw_mstkelurahan WHERE namaKelurahan LIKE IN_namaKelurahan;

        END CASE ;

    WHEN 'create' THEN
      INSERT INTO tbl_mstkelurahan (idKecamatan, namaKelurahan, createdBy, createdDate) VALUES (IN_idKecamatan, IN_namaKelurahan, CREATED_BY, now());

    WHEN 'update' THEN
      UPDATE tbl_mstkelurahan SET idKecamatan = IN_idKecamatan, namaKelurahan = IN_namaKelurahan, updatedBy = UPDATED_BY, updatedDate = now() WHERE idKelurahan = IN_idKelurahan;

    WHEN 'delete' THEN
      DELETE FROM tbl_mstkelurahan WHERE idKelurahan = IN_idKelurahan;

  END CASE ;

END;

