create
  definer = root@localhost procedure sp_mstjabatan(IN KEY_CALL varchar(20), IN KOLOM varchar(40), IN IN_idJabatan int,
                                                   IN IN_idPerusahaan int, IN IN_namaJabatan varchar(255),
                                                   IN IN_singkatanJabatan varchar(255), IN IN_statusJabatan tinyint(1),
                                                   IN CREATED_BY varchar(50), IN UPDATED_BY varchar(50))
BEGIN

  CASE KEY_CALL
    WHEN 'getAll' THEN
    SELECT * FROM vw_mstjabatan;

    WHEN 'getData' THEN
      CASE KOLOM
        WHEN 'idJabatan' THEN
        SELECT * FROM vw_mstjabatan WHERE idJabatan = IN_idJabatan;

        WHEN 'namaJabatan' THEN
        SELECT * FROM vw_mstjabatan WHERE namaJabatan LIKE IN_namaJabatan;
        END CASE ;

    WHEN 'create' THEN
      INSERT INTO tbl_mstjabatan (idPerusahaan, namaJabatan, singkatanJabatan, statusJabatan, createdBy, createdDate)
                             VALUES (IN_idPerusahaan, IN_namaJabatan, IN_singkatanJabatan, IN_statusJabatan, CREATED_BY, NOW());

    WHEN 'update' THEN
      UPDATE tbl_mstjabatan SET
                                   idPerusahaan = IN_idPerusahaan,
                                   namaJabatan = IN_namaJabatan,
                                   singkatanJabatan = IN_singkatanJabatan,
                                   statusJabatan = IN_statusJabatan,
                                   updatedBy = UPDATED_BY,
                                   updatedDate = now()
      WHERE idJabatan = IN_idJabatan;

    WHEN 'delete' THEN
      DELETE FROM tbl_mstjabatan WHERE idJabatan = IN_idJabatan;

  END CASE ;

END;

