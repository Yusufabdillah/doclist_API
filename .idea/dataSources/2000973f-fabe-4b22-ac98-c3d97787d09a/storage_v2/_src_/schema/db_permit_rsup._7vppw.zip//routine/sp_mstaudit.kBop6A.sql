create
  definer = root@localhost procedure sp_mstaudit(IN KEY_CALL varchar(20), IN KOLOM varchar(40), IN IN_idAudit int,
                                                 IN IN_namaAudit varchar(100), IN IN_deskripsiAudit text,
                                                 IN CREATED_BY varchar(50), IN UPDATED_BY varchar(50))
BEGIN

  CASE KEY_CALL
    WHEN 'getAll' THEN
    SELECT * FROM tbl_mstaudit;

    WHEN 'getData' THEN
      CASE KOLOM
        WHEN 'idAudit' THEN
        SELECT * FROM tbl_mstaudit WHERE idAudit = IN_idAudit;

        WHEN 'namaAudit' THEN
        SELECT * FROM tbl_mstaudit WHERE namaAudit LIKE IN_namaAudit;
        END CASE ;

    WHEN 'create' THEN
      INSERT INTO tbl_mstaudit (namaAudit, deskripsiAudit, createdBy, createdDate) VALUES (IN_namaAudit, IN_deskripsiAudit, CREATED_BY, NOW());

    WHEN 'update' THEN
      UPDATE tbl_mstaudit SET
            namaAudit = IN_namaAudit,
            deskripsiAudit = IN_deskripsiAudit,
            updatedBy = UPDATED_BY,
            updatedDate = now()
      WHERE idAudit = IN_idAudit;

    WHEN 'delete' THEN
      DELETE FROM tbl_mstaudit WHERE idAudit = IN_idAudit;

  END CASE ;

END;

