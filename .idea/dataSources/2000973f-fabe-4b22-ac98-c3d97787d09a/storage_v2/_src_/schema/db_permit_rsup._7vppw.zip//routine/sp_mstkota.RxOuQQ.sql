create
  definer = root@localhost procedure sp_mstkota(IN KEY_CALL varchar(20), IN KOLOM varchar(40), IN IN_idKota int,
                                                IN IN_idNegara int, IN IN_idProvinsi int, IN IN_namaKota varchar(100),
                                                IN IN_namaNegara varchar(20), IN IN_namaProvinsi varchar(255),
                                                IN CREATED_BY varchar(50), IN UPDATED_BY varchar(50))
BEGIN

  CASE KEY_CALL
    WHEN 'getAll' THEN
    SELECT * FROM vw_mstkota;

    WHEN 'getData' THEN
      CASE KOLOM
        WHEN 'idKota' THEN
        SELECT * FROM vw_mstkota WHERE idKota LIKE IN_idKota;

        WHEN 'idNegara' THEN
        SELECT * FROM vw_mstkota WHERE idNegara = IN_idNegara;

        WHEN 'idProvinsi' THEN
        SELECT * FROM vw_mstkota WHERE idProvinsi = IN_idProvinsi;

        WHEN 'namaKota' THEN
        SELECT * FROM vw_mstkota WHERE namaKota LIKE IN_namaKota;

        WHEN 'namaNegara' THEN
        SELECT * FROM vw_mstkota WHERE namaNegara LIKE IN_namaNegara;

        WHEN 'namaProvinsi' THEN
        SELECT * FROM vw_mstkota WHERE namaProvinsi LIKE IN_namaProvinsi;
        END CASE ;

    WHEN 'create' THEN
      INSERT INTO tbl_mstkota (idProvinsi, namaKota, createdBy, createdDate) VALUES (IN_idProvinsi, IN_namaKota, CREATED_BY, now());

    WHEN 'update' THEN
      UPDATE tbl_mstkota SET idProvinsi = IN_idProvinsi, namaKota = IN_namaKota, updatedBy = UPDATED_BY, updatedDate = now() WHERE idKota = IN_idKota;

    WHEN 'delete' THEN
      DELETE FROM tbl_mstkota WHERE idKota = IN_idKota;

  END CASE ;

END;

