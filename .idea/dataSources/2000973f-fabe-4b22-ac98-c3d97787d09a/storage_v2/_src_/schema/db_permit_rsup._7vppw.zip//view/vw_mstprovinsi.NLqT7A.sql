create definer = root@localhost view vw_mstprovinsi as
select `db_permit_rsup`.`tbl_mstprovinsi`.`idProvinsi`    AS `idProvinsi`,
       `db_permit_rsup`.`tbl_mstprovinsi`.`idNegara`      AS `idNegara`,
       `db_permit_rsup`.`tbl_mstnegara`.`namaNegara`      AS `namaNegara`,
       `db_permit_rsup`.`tbl_mstnegara`.`singkatanNegara` AS `singkatanNegara`,
       `db_permit_rsup`.`tbl_mstprovinsi`.`namaProvinsi`  AS `namaProvinsi`,
       `db_permit_rsup`.`tbl_mstprovinsi`.`createdBy`     AS `createdBy`,
       `db_permit_rsup`.`tbl_mstprovinsi`.`createdDate`   AS `createdDate`,
       `db_permit_rsup`.`tbl_mstprovinsi`.`updatedBy`     AS `updatedBy`,
       `db_permit_rsup`.`tbl_mstprovinsi`.`updatedDate`   AS `updatedDate`
from (`db_permit_rsup`.`tbl_mstprovinsi`
       left join `db_permit_rsup`.`tbl_mstnegara`
                 on ((`db_permit_rsup`.`tbl_mstprovinsi`.`idNegara` = `db_permit_rsup`.`tbl_mstnegara`.`idNegara`)))
order by `db_permit_rsup`.`tbl_mstprovinsi`.`idProvinsi`;

