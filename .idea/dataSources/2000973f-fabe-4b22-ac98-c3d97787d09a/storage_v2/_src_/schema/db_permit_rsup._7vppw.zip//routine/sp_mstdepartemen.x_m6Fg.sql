create
  definer = root@localhost procedure sp_mstdepartemen(IN KEY_CALL varchar(20), IN KOLOM varchar(40),
                                                      IN IN_idDepartemen int, IN IN_idPerusahaan int,
                                                      IN IN_namaDepartemen varchar(255),
                                                      IN IN_singkatanDepartemen varchar(20),
                                                      IN IN_statusDepartemen tinyint(1), IN CREATED_BY varchar(50),
                                                      IN UPDATED_BY varchar(50))
BEGIN

  CASE KEY_CALL
    WHEN 'getAll' THEN
    SELECT * FROM vw_mstdepartemen;

    WHEN 'getData' THEN
      CASE KOLOM
        WHEN 'idDepartemen' THEN
        SELECT * FROM vw_mstdepartemen WHERE idDepartemen = IN_idDepartemen;

        WHEN 'namaDepartemen' THEN
        SELECT * FROM vw_mstdepartemen WHERE namaDepartemen LIKE IN_namaDepartemen;
        END CASE ;

    WHEN 'create' THEN
      INSERT INTO tbl_mstdepartemen (idPerusahaan, namaDepartemen, singkatanDepartemen, statusDepartemen, createdBy, createdDate)
                             VALUES (IN_idPerusahaan, IN_namaDepartemen, IN_singkatanDepartemen, IN_statusDepartemen, CREATED_BY, now());

    WHEN 'update' THEN
      UPDATE tbl_mstdepartemen SET 
                                   idPerusahaan = IN_idPerusahaan,
                                   namaDepartemen = IN_namaDepartemen, 
                                   singkatanDepartemen = IN_singkatanDepartemen, 
                                   statusDepartemen = IN_statusDepartemen, 
                                   updatedBy = UPDATED_BY, 
                                   updatedDate = now() 
      WHERE idDepartemen = IN_idDepartemen;

    WHEN 'delete' THEN
      DELETE FROM tbl_mstdepartemen WHERE idDepartemen = IN_idDepartemen;

  END CASE ;

END;

