create definer = root@localhost view vw_mstkota as
select `db_permit_rsup`.`tbl_mstkota`.`idKota`             AS `idKota`,
       `db_permit_rsup`.`vw_mstprovinsi`.`idNegara`        AS `idNegara`,
       `db_permit_rsup`.`vw_mstprovinsi`.`namaNegara`      AS `namaNegara`,
       `db_permit_rsup`.`vw_mstprovinsi`.`singkatanNegara` AS `singkatanNegara`,
       `db_permit_rsup`.`tbl_mstkota`.`idProvinsi`         AS `idProvinsi`,
       `db_permit_rsup`.`vw_mstprovinsi`.`namaProvinsi`    AS `namaProvinsi`,
       `db_permit_rsup`.`tbl_mstkota`.`namaKota`           AS `namaKota`,
       `db_permit_rsup`.`tbl_mstkota`.`createdBy`          AS `createdBy`,
       `db_permit_rsup`.`tbl_mstkota`.`createdDate`        AS `createdDate`,
       `db_permit_rsup`.`tbl_mstkota`.`updatedBy`          AS `updatedBy`,
       `db_permit_rsup`.`tbl_mstkota`.`updatedDate`        AS `updatedDate`
from ((`db_permit_rsup`.`tbl_mstkota` left join `db_permit_rsup`.`vw_mstprovinsi` on ((
    `db_permit_rsup`.`tbl_mstkota`.`idProvinsi` = `db_permit_rsup`.`vw_mstprovinsi`.`idProvinsi`)))
       left join `db_permit_rsup`.`tbl_mstnegara`
                 on ((`db_permit_rsup`.`vw_mstprovinsi`.`idNegara` = `db_permit_rsup`.`tbl_mstnegara`.`idNegara`)))
order by `db_permit_rsup`.`tbl_mstkota`.`idKota`;

