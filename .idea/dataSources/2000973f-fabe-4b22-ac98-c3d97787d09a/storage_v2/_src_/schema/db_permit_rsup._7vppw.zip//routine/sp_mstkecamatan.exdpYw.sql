create
  definer = root@localhost procedure sp_mstkecamatan(IN KEY_CALL varchar(20), IN KOLOM varchar(40),
                                                     IN IN_idKecamatan int, IN IN_idKota int,
                                                     IN IN_namaKecamatan varchar(100),
                                                     IN IN_kodeposKecamatan varchar(20), IN CREATED_BY varchar(50),
                                                     IN UPDATED_BY varchar(50))
BEGIN

  CASE KEY_CALL
    WHEN 'getAll' THEN
    SELECT * FROM vw_mstkecamatan;

    WHEN 'getData' THEN
      CASE KOLOM
        WHEN 'idKecamatan' THEN
        SELECT * FROM vw_mstkecamatan WHERE idKecamatan LIKE IN_idKecamatan;
        
        WHEN 'idKota' THEN
        SELECT * FROM vw_mstkecamatan WHERE idKota LIKE IN_idKota;

        WHEN 'namaKecamatan' THEN
        SELECT * FROM vw_mstkecamatan WHERE namaKecamatan LIKE IN_namaKecamatan;

        WHEN 'kodeposKecamatan' THEN
        SELECT * FROM vw_mstkecamatan WHERE kodeposKecamatan LIKE IN_kodeposKecamatan;
        END CASE ;

    WHEN 'create' THEN
      INSERT INTO tbl_mstkecamatan (idKota, namaKecamatan, kodeposKecamatan, createdBy, createdDate) VALUES (IN_idKota, IN_namaKecamatan, IN_kodeposKecamatan, CREATED_BY, now());

    WHEN 'update' THEN
      UPDATE tbl_mstkecamatan SET idKota = IN_idKota, namaKecamatan = IN_namaKecamatan, kodeposKecamatan = IN_kodeposKecamatan, updatedBy = UPDATED_BY, updatedDate = now() WHERE idKecamatan = IN_idKecamatan;

    WHEN 'delete' THEN
      DELETE FROM tbl_mstkecamatan WHERE idKecamatan = IN_idKecamatan;

  END CASE ;

END;

