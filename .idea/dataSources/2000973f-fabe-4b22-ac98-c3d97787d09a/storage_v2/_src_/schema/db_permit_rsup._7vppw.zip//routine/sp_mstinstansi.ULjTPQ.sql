create
  definer = root@localhost procedure sp_mstinstansi(IN KEY_CALL varchar(20), IN KOLOM varchar(40), IN IN_idInstansi int,
                                                    IN IN_idKota int, IN IN_namaInstansi varchar(255),
                                                    IN IN_alamatInstansi varchar(255),
                                                    IN IN_kepalaInstansi varchar(255),
                                                    IN IN_jbt_kplInstansi varchar(255), IN CREATED_BY varchar(50),
                                                    IN UPDATED_BY varchar(50))
BEGIN

  CASE KEY_CALL
    WHEN 'getAll' THEN
    SELECT * FROM vw_mstinstansi;

    WHEN 'getData' THEN
      CASE KOLOM
        WHEN 'idInstansi' THEN
        SELECT * FROM vw_mstinstansi WHERE idInstansi = IN_idInstansi;

        WHEN 'namaInstansi' THEN
        SELECT * FROM vw_mstinstansi WHERE namaInstansi LIKE IN_namaInstansi;
        END CASE ;

    WHEN 'create' THEN
      INSERT INTO tbl_mstinstansi (idKota, namaInstansi, alamatInstansi, kepalaInstansi, jbt_kplInstansi, createdBy, createdDate)
                             VALUES (IN_idKota, IN_namaInstansi, IN_alamatInstansi, IN_kepalaInstansi, IN_jbt_kplInstansi, CREATED_BY, now());

    WHEN 'update' THEN
      UPDATE tbl_mstinstansi SET
                                   idKota = IN_idKota,
                                   namaInstansi = IN_namaInstansi,
                                   alamatInstansi = IN_alamatInstansi,
                                 kepalaInstansi = IN_kepalaInstansi,
                                 jbt_kplInstansi = IN_jbt_kplInstansi,
                                   updatedBy = UPDATED_BY,
                                   updatedDate = now()
      WHERE idInstansi = IN_idInstansi;

    WHEN 'delete' THEN
      DELETE FROM tbl_mstinstansi WHERE idInstansi = IN_idInstansi;

  END CASE ;

END;

