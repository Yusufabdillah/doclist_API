create definer = root@localhost view vw_smsreminderperhari as
select `b`.`idUser`                      AS `idUser`,
       `b`.`namaUser`                    AS `namaUser`,
       `b`.`telpUser`                    AS `telpUser`,
       `a`.`idDokumen`                   AS `idDokumen`,
       `a`.`idDepartemen`                AS `idDepartemen`,
       `a`.`idInstansi`                  AS `idInstansi`,
       `a`.`judulDokumen`                AS `judulDokumen`,
       `a`.`nomorDokumen`                AS `nomorDokumen`,
       `a`.`deskripsiDokumen`            AS `deskripsiDokumen`,
       `a`.`expired_unlimitedDokumen`    AS `expired_unlimitedDokumen`,
       `a`.`kpl_insDokumen`              AS `kpl_insDokumen`,
       `a`.`jbt_kpl_insDokumen`          AS `jbt_kpl_insDokumen`,
       `a`.`tgl_terbitDokumen`           AS `tgl_terbitDokumen`,
       `a`.`tgl_habisDokumen`            AS `tgl_habisDokumen`,
       `a`.`AwalReminder`                AS `AwalReminder`,
       `a`.`durasiReminder`              AS `durasiReminder`,
       `a`.`statusReminder`              AS `statusReminder`,
       `a`.`statusDokumen`               AS `statusDokumen`,
       `a`.`tipeDokumen`                 AS `tipeDokumen`,
       `a`.`rentang_hari_berlakuDokumen` AS `rentang_hari_berlakuDokumen`,
       `a`.`casenumberDokumen`           AS `casenumberDokumen`,
       `a`.`fileDokumen`                 AS `fileDokumen`,
       `a`.`createdBy`                   AS `createdBy`,
       `a`.`createdDate`                 AS `createdDate`,
       `a`.`updatedBy`                   AS `updatedBy`,
       `a`.`updatedDate`                 AS `updatedDate`
from (`db_permit_rsup`.`tbl_mstuser` `b`
       left join `db_permit_rsup`.`tbl_mstdokumen` `a` on ((`a`.`idDepartemen` = `b`.`idDepartemen`)))
where (((now() between (`a`.`tgl_habisDokumen` + interval (-(1) * `a`.`AwalReminder`) day) and `a`.`tgl_habisDokumen`) and
        (((to_days(now()) - to_days((`a`.`tgl_habisDokumen` + interval (-(1) * `a`.`AwalReminder`) day))) %
          `a`.`durasiReminder`) = 0) and (`a`.`AwalReminder` <> 0)) or
       ((now() between (`a`.`tgl_habisDokumen` + interval (-(1) * 105) day) and `a`.`tgl_habisDokumen`) and
        (((to_days(now()) - to_days((`a`.`tgl_habisDokumen` + interval (-(1) * 45) day))) % 3) = 0) and
        (`a`.`AwalReminder` = 0)));

