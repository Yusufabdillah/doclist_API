create definer = root@localhost view vw_mstkecamatan as
select `db_permit_rsup`.`tbl_mstkecamatan`.`idKecamatan`      AS `idKecamatan`,
       `db_permit_rsup`.`vw_mstkota`.`idNegara`               AS `idNegara`,
       `db_permit_rsup`.`vw_mstkota`.`namaNegara`             AS `namaNegara`,
       `db_permit_rsup`.`vw_mstkota`.`singkatanNegara`        AS `singkatanNegara`,
       `db_permit_rsup`.`vw_mstkota`.`idProvinsi`             AS `idProvinsi`,
       `db_permit_rsup`.`vw_mstkota`.`namaProvinsi`           AS `namaProvinsi`,
       `db_permit_rsup`.`vw_mstkota`.`idKota`                 AS `idKota`,
       `db_permit_rsup`.`vw_mstkota`.`namaKota`               AS `namaKota`,
       `db_permit_rsup`.`tbl_mstkecamatan`.`namaKecamatan`    AS `namaKecamatan`,
       `db_permit_rsup`.`tbl_mstkecamatan`.`kodeposKecamatan` AS `kodeposKecamatan`,
       `db_permit_rsup`.`tbl_mstkecamatan`.`createdBy`        AS `createdBy`,
       `db_permit_rsup`.`tbl_mstkecamatan`.`createdDate`      AS `createdDate`,
       `db_permit_rsup`.`tbl_mstkecamatan`.`updatedBy`        AS `updatedBy`,
       `db_permit_rsup`.`tbl_mstkecamatan`.`updatedDate`      AS `updatedDate`
from (`db_permit_rsup`.`tbl_mstkecamatan`
       left join `db_permit_rsup`.`vw_mstkota`
                 on ((`db_permit_rsup`.`vw_mstkota`.`idKota` = `db_permit_rsup`.`tbl_mstkecamatan`.`idKota`)))
order by `db_permit_rsup`.`tbl_mstkecamatan`.`idKecamatan`;

