create
  definer = root@localhost procedure sp_utlmenuakses_backend(IN KEY_CALL varchar(20), IN KOLOM varchar(40),
                                                             IN IN_idGrup int, IN IN_idMenu int)
BEGIN

  CASE KEY_CALL
    WHEN 'getAll_lv1' THEN
                  SELECT idMenu, menuLabel, menuIcon, menuLink FROM tbl_utlmenu_lv1;

    WHEN 'getAll_lv2' THEN
                  SELECT idMenu, menuLabel, menuIcon, menuLink, menuHeader FROM tbl_utlmenu_lv2;

    WHEN 'getAll_lv3' THEN
                  SELECT idMenu, menuLabel, menuIcon, menuLink, menuHeader FROM tbl_utlmenu_lv3;

    WHEN 'getData_lv1' THEN
      SELECT m1.idGrup, m2.idMenu, m2.menuLabel, m2.menuIcon, m2.menuLink
      FROM tbl_utlmenuakses_backend AS m1 INNER JOIN tbl_utlmenu_lv1 AS m2 ON m1.idMenu = m2.idMenu
      WHERE m1.idGrup = IN_idGrup;

    WHEN 'getData_lv2' THEN
      SELECT m1.idGrup, m2.idMenu, m2.menuLabel, m2.menuIcon, m2.menuLink, m2.menuHeader
      FROM tbl_utlmenuakses_backend AS m1 INNER JOIN tbl_utlmenu_lv2 AS m2 ON m1.idMenu = m2.idMenu
      WHERE m1.idGrup = IN_idGrup;

    WHEN 'getData_lv3' THEN
      SELECT m1.idGrup, m2.idMenu, m2.menuLabel, m2.menuIcon, m2.menuLink, m2.menuHeader
      FROM tbl_utlmenuakses_backend AS m1 INNER JOIN tbl_utlmenu_lv3 AS m2 ON m1.idMenu = m2.idMenu
      WHERE m1.idGrup = IN_idGrup;

    WHEN 'getMenu_lv1' THEN
      SELECT m1.idGrup, m2.idMenu, m2.menuLabel, m2.menuIcon, m2.menuLink, 1 AS Atc
      FROM tbl_utlmenuakses_backend AS m1 INNER JOIN tbl_utlmenu_lv1 AS m2 ON m1.idMenu = m2.idMenu
      WHERE m1.idGrup = IN_idGrup
      UNION ALL SELECT NULL AS idGrup, idMenu, menuLabel, menuIcon, menuLink, 0 AS Atc
      FROM tbl_utlmenu_lv1 WHERE idMenu NOT IN (SELECT idMenu FROM tbl_utlmenuakses_backend WHERE (idGrup = IN_idGrup))
      ORDER BY idMenu ASC;

    WHEN 'getMenu_lv2' THEN
      SELECT m1.idGrup, m2.idMenu, m2.menuLabel, m2.menuIcon, m2.menuLink, m2.menuHeader, 1 AS Atc
      FROM tbl_utlmenuakses_backend AS m1 INNER JOIN tbl_utlmenu_lv2 AS m2 ON m1.idMenu = m2.idMenu
      WHERE m1.idGrup = IN_idGrup
      UNION ALL SELECT NULL AS idGrup, idMenu, menuLabel, menuIcon, menuLink, menuHeader, 0 AS Atc
      FROM tbl_utlmenu_lv2 WHERE idMenu NOT IN (SELECT idMenu FROM tbl_utlmenuakses_backend WHERE (idGrup = IN_idGrup))
      ORDER BY idMenu ASC;

    WHEN 'getMenu_lv3' THEN
      SELECT m1.idGrup, m2.idMenu, m2.menuLabel, m2.menuIcon, m2.menuLink, m2.menuHeader, 1 AS Atc
      FROM tbl_utlmenuakses_backend AS m1 INNER JOIN tbl_utlmenu_lv3 AS m2 ON m1.idMenu = m2.idMenu
      WHERE m1.idGrup = IN_idGrup
      UNION ALL SELECT NULL AS idGrup, idMenu, menuLabel, menuIcon, menuLink, menuHeader, 0 AS Atc
      FROM tbl_utlmenu_lv3 WHERE idMenu NOT IN (SELECT idMenu FROM tbl_utlmenuakses_backend WHERE (idGrup = IN_idGrup))
      ORDER BY idMenu ASC;

    WHEN 'create' THEN
      INSERT INTO tbl_utlmenuakses_backend (idGrup, idMenu) VALUES (IN_idGrup, IN_idMenu);

    WHEN 'delete' THEN
      DELETE FROM tbl_utlmenuakses_backend WHERE idGrup = IN_idGrup;

  END CASE ;

END;

