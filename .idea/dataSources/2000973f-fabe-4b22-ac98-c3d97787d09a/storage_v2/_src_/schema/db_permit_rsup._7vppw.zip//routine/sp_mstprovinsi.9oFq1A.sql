create
  definer = root@localhost procedure sp_mstprovinsi(IN KEY_CALL varchar(20), IN KOLOM varchar(40), IN IN_idProvinsi int,
                                                    IN IN_idNegara int, IN IN_namaNegara varchar(100),
                                                    IN IN_singkatanNegara varchar(20), IN IN_namaProvinsi varchar(255),
                                                    IN CREATED_BY varchar(50), IN UPDATED_BY varchar(50))
BEGIN

  CASE KEY_CALL
    WHEN 'getAll' THEN
    SELECT * FROM vw_mstprovinsi;

    WHEN 'getData' THEN
      CASE KOLOM
        WHEN 'idProvinsi' THEN
        SELECT * FROM vw_mstprovinsi WHERE idProvinsi = IN_idProvinsi;

        WHEN 'idNegara' THEN
        SELECT * FROM vw_mstprovinsi WHERE idNegara = IN_idNegara;

        WHEN 'namaNegara' THEN
        SELECT * FROM vw_mstprovinsi WHERE namaNegara LIKE IN_namaNegara;

        WHEN 'singkatanNegara' THEN
        SELECT * FROM vw_mstprovinsi WHERE singkatanNegara LIKE IN_singkatanNegara;

        WHEN 'namaProvinsi' THEN
        SELECT * FROM vw_mstprovinsi WHERE namaProvinsi LIKE IN_namaProvinsi;
        END CASE ;

    WHEN 'create' THEN
      INSERT INTO tbl_mstprovinsi (idNegara, namaProvinsi, createdBy, createdDate) VALUES (IN_idNegara, IN_namaProvinsi, CREATED_BY, now());

    WHEN 'update' THEN
      UPDATE tbl_mstprovinsi SET idNegara = IN_idNegara, namaProvinsi = IN_namaProvinsi, updatedBy = UPDATED_BY, updatedDate = now() WHERE idProvinsi = IN_idProvinsi;

    WHEN 'delete' THEN
      DELETE FROM tbl_mstprovinsi WHERE idProvinsi = IN_idProvinsi;

  END CASE ;

END;

