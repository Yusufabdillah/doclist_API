create definer = root@localhost view vw_mstkelurahan as
select `db_permit_rsup`.`tbl_mstkelurahan`.`idKelurahan`   AS `idKelurahan`,
       `db_permit_rsup`.`tbl_mstkelurahan`.`idKecamatan`   AS `idKecamatan`,
       `vw_mstkecamatan`.`namaKecamatan`                   AS `namaKecamatan`,
       `vw_mstkecamatan`.`kodeposKecamatan`                AS `kodeposKecamatan`,
       `vw_mstkecamatan`.`idKota`                          AS `idKota`,
       `vw_mstkecamatan`.`namaKota`                        AS `namaKota`,
       `vw_mstkecamatan`.`idProvinsi`                      AS `idProvinsi`,
       `vw_mstkecamatan`.`namaProvinsi`                    AS `namaProvinsi`,
       `vw_mstkecamatan`.`idNegara`                        AS `idNegara`,
       `vw_mstkecamatan`.`namaNegara`                      AS `namaNegara`,
       `vw_mstkecamatan`.`singkatanNegara`                 AS `singkatanNegara`,
       `db_permit_rsup`.`tbl_mstkelurahan`.`namaKelurahan` AS `namaKelurahan`,
       `db_permit_rsup`.`tbl_mstkelurahan`.`createdBy`     AS `createdBy`,
       `db_permit_rsup`.`tbl_mstkelurahan`.`createdDate`   AS `createdDate`,
       `db_permit_rsup`.`tbl_mstkelurahan`.`updatedBy`     AS `updatedBy`,
       `db_permit_rsup`.`tbl_mstkelurahan`.`updatedDate`   AS `updatedDate`
from (`db_permit_rsup`.`tbl_mstkelurahan`
       left join `db_permit_rsup`.`vw_mstkecamatan`
                 on ((`db_permit_rsup`.`tbl_mstkelurahan`.`idKecamatan` = `vw_mstkecamatan`.`idKecamatan`)))
order by `db_permit_rsup`.`tbl_mstkelurahan`.`idKelurahan`;

