create definer = root@localhost view vw_mstjabatan as
select `db_permit_rsup`.`tbl_mstjabatan`.`idJabatan`              AS `idJabatan`,
       `db_permit_rsup`.`tbl_mstjabatan`.`idPerusahaan`           AS `idPerusahaan`,
       `db_permit_rsup`.`tbl_mstperusahaan`.`namaPerusahaan`      AS `namaPerusahaan`,
       `db_permit_rsup`.`tbl_mstperusahaan`.`lokasiPerusahaan`    AS `lokasiPerusahaan`,
       `db_permit_rsup`.`tbl_mstperusahaan`.`singkatanPerusahaan` AS `singkatanPerusahaan`,
       `db_permit_rsup`.`tbl_mstjabatan`.`namaJabatan`            AS `namaJabatan`,
       `db_permit_rsup`.`tbl_mstjabatan`.`singkatanJabatan`       AS `singkatanJabatan`,
       `db_permit_rsup`.`tbl_mstjabatan`.`statusJabatan`          AS `statusJabatan`,
       `db_permit_rsup`.`tbl_mstjabatan`.`createdBy`              AS `createdBy`,
       `db_permit_rsup`.`tbl_mstjabatan`.`createdDate`            AS `createdDate`,
       `db_permit_rsup`.`tbl_mstjabatan`.`updatedBy`              AS `updatedBy`,
       `db_permit_rsup`.`tbl_mstjabatan`.`updatedDate`            AS `updatedDate`
from (`db_permit_rsup`.`tbl_mstjabatan`
       left join `db_permit_rsup`.`tbl_mstperusahaan` on ((`db_permit_rsup`.`tbl_mstjabatan`.`idPerusahaan` =
                                                           `db_permit_rsup`.`tbl_mstperusahaan`.`idPerusahaan`)))
order by `db_permit_rsup`.`tbl_mstjabatan`.`idJabatan`;

