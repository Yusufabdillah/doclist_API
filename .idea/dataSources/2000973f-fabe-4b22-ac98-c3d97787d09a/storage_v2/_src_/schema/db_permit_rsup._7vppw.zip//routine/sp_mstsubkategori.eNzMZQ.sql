create
  definer = root@localhost procedure sp_mstsubkategori(IN KEY_CALL varchar(20), IN KOLOM varchar(40), IN IN_idSubk int,
                                                       IN IN_idKategori int, IN IN_namaSubk varchar(100),
                                                       IN CREATED_BY varchar(50), IN UPDATED_BY varchar(50))
BEGIN

  CASE KEY_CALL
    WHEN 'getAll' THEN
    SELECT * FROM vw_mstsubkategori;

    WHEN 'getData' THEN
      CASE KOLOM
        WHEN 'idSubk' THEN
        SELECT * FROM vw_mstsubkategori WHERE idSubk = IN_idSubk;

        WHEN 'idKategori' THEN
        SELECT * FROM vw_mstsubkategori WHERE idKategori = IN_idKategori;

        WHEN 'namaSubk' THEN
        SELECT * FROM vw_mstsubkategori WHERE namaSubk LIKE IN_namaSubk;

        END CASE ;

    WHEN 'create' THEN
      INSERT INTO tbl_mstsubkategori (idKategori, namaSubk, createdBy, createdDate) VALUES (IN_idKategori, IN_namaSubk, CREATED_BY, now());

    WHEN 'update' THEN
      UPDATE tbl_mstsubkategori SET idKategori = IN_idKategori, namaSubk = IN_namaSubk, updatedBy = UPDATED_BY, updatedDate = now() WHERE idSubk = IN_idSubk;

    WHEN 'delete' THEN
      DELETE FROM tbl_mstsubkategori WHERE idSubk = IN_idSubk;

  END CASE ;

END;

