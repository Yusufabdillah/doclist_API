create definer = root@localhost view vw_mstgrupuser as
select `db_permit_rsup`.`tbl_mstgrupuser`.`idGrup`                AS `idGrup`,
       `db_permit_rsup`.`tbl_mstgrupuser`.`namaGrup`              AS `namaGrup`,
       `db_permit_rsup`.`tbl_mstgrupuser`.`idAkses`               AS `idAkses`,
       `db_permit_rsup`.`tbl_mstgrupuser`.`idPerusahaan`          AS `idPerusahaan`,
       `db_permit_rsup`.`tbl_mstgrupuser`.`createdBy`             AS `createdBy`,
       `db_permit_rsup`.`tbl_mstgrupuser`.`createdDate`           AS `createdDate`,
       `db_permit_rsup`.`tbl_mstgrupuser`.`updatedBy`             AS `updatedBy`,
       `db_permit_rsup`.`tbl_mstgrupuser`.`updatedDate`           AS `updatedDate`,
       `db_permit_rsup`.`tbl_mstakses`.`namaAkses`                AS `namaAkses`,
       `db_permit_rsup`.`tbl_mstperusahaan`.`namaPerusahaan`      AS `namaPerusahaan`,
       `db_permit_rsup`.`tbl_mstperusahaan`.`lokasiPerusahaan`    AS `lokasiPerusahaan`,
       `db_permit_rsup`.`tbl_mstperusahaan`.`singkatanPerusahaan` AS `singkatanPerusahaan`
from ((`db_permit_rsup`.`tbl_mstgrupuser` left join `db_permit_rsup`.`tbl_mstakses` on ((
    `db_permit_rsup`.`tbl_mstgrupuser`.`idAkses` = `db_permit_rsup`.`tbl_mstakses`.`idAkses`)))
       left join `db_permit_rsup`.`tbl_mstperusahaan` on ((`db_permit_rsup`.`tbl_mstgrupuser`.`idPerusahaan` =
                                                           `db_permit_rsup`.`tbl_mstperusahaan`.`idPerusahaan`)))
order by `db_permit_rsup`.`tbl_mstgrupuser`.`idGrup`;

