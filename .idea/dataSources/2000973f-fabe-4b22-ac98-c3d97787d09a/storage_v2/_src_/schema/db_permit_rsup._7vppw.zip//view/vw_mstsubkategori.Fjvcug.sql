create definer = root@localhost view vw_mstsubkategori as
select `db_permit_rsup`.`tbl_mstsubkategori`.`idSubk`      AS `idSubk`,
       `db_permit_rsup`.`tbl_mstsubkategori`.`idKategori`  AS `idKategori`,
       `db_permit_rsup`.`tbl_mstkategori`.`namaKategori`   AS `namaKategori`,
       `db_permit_rsup`.`tbl_mstsubkategori`.`namaSubk`    AS `namaSubk`,
       `db_permit_rsup`.`tbl_mstsubkategori`.`createdBy`   AS `createdBy`,
       `db_permit_rsup`.`tbl_mstsubkategori`.`createdDate` AS `createdDate`,
       `db_permit_rsup`.`tbl_mstsubkategori`.`updatedBy`   AS `updatedBy`,
       `db_permit_rsup`.`tbl_mstsubkategori`.`updatedDate` AS `updatedDate`
from (`db_permit_rsup`.`tbl_mstsubkategori`
       left join `db_permit_rsup`.`tbl_mstkategori` on ((`db_permit_rsup`.`tbl_mstkategori`.`idKategori` =
                                                         `db_permit_rsup`.`tbl_mstsubkategori`.`idKategori`)))
order by `db_permit_rsup`.`tbl_mstsubkategori`.`idSubk`;

