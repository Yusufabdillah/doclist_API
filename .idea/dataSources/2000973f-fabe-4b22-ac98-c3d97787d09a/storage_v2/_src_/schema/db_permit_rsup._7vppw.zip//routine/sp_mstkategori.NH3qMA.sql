create
  definer = root@localhost procedure sp_mstkategori(IN KEY_CALL varchar(20), IN KOLOM varchar(40), IN IN_idKategori int,
                                                    IN IN_namaKategori varchar(100), IN CREATED_BY varchar(50),
                                                    IN UPDATED_BY varchar(50))
BEGIN

  CASE KEY_CALL
    WHEN 'getAll' THEN
    SELECT * FROM tbl_mstkategori;

    WHEN 'getData' THEN
      CASE KOLOM
        WHEN 'idKategori' THEN
        SELECT * FROM tbl_mstkategori WHERE idKategori = IN_idKategori;

        WHEN 'namaKategori' THEN
        SELECT * FROM tbl_mstkategori WHERE namaKategori LIKE IN_namaKategori;

        END CASE ;

    WHEN 'create' THEN
      INSERT INTO tbl_mstkategori (namaKategori, createdBy, createdDate) VALUES (IN_namaKategori, CREATED_BY, now());

    WHEN 'update' THEN
      UPDATE tbl_mstkategori SET namaKategori = IN_namaKategori, updatedBy = UPDATED_BY, updatedDate = now() WHERE idKategori = IN_idKategori;

    WHEN 'delete' THEN
      DELETE FROM tbl_mstkategori WHERE idKategori = IN_idKategori;

  END CASE ;

END;

