create
  definer = root@localhost procedure sp_utldepartemenakses(IN KEY_CALL varchar(20), IN KOLOM varchar(40),
                                                           IN IN_idGrup int, IN IN_idDepartemen int)
BEGIN

  CASE KEY_CALL
    WHEN 'getAll' THEN
      SELECT m1.idGrup, m2.idPerusahaan, m2.singkatanDepartemen, m2.namaDepartemen, m2.statusDepartemen
      FROM tbl_utldepartemenakses AS m1 INNER JOIN tbl_mstdepartemen AS m2 ON m1.idDepartemen = m2.`﻿idDepartemen`;

    WHEN 'getDataSite' THEN
      SELECT m1.idGrup, m2.idPerusahaan, m2.singkatanDepartemen, m2.namaDepartemen, m2.statusDepartemen
      FROM tbl_utldepartemenakses AS m1 INNER JOIN tbl_mstdepartemen AS m2 ON m1.idDepartemen = m2.`﻿idDepartemen`
      WHERE m1.idGrup = IN_idGrup;

    WHEN 'getViewSite' THEN
      SELECT m1.idGrup, m2.idPerusahaan, m2.singkatanDepartemen, m2.namaDepartemen, m2.statusDepartemen, 1 AS Atc
      FROM tbl_utldepartemenakses AS m1 INNER JOIN tbl_mstdepartemen AS m2 ON m1.idDepartemen = m2.`﻿idDepartemen`
      WHERE m1.idGrup = IN_idGrup
      UNION ALL SELECT NULL AS idGrup, idPerusahaan, singkatanDepartemen, namaDepartemen, statusDepartemen, 0 AS Atc
      FROM tbl_mstdepartemen WHERE `﻿idDepartemen` NOT IN (SELECT idDepartemen FROM tbl_utldepartemenakses WHERE (idGrup = IN_idGrup))
      ORDER BY idDepartemen ASC;

    WHEN 'create' THEN
      INSERT INTO tbl_utldepartemenakses (idGrup, idDepartemen) VALUES (IN_idGrup, IN_idDepartemen);

    WHEN 'delete' THEN
      DELETE FROM tbl_utldepartemenakses WHERE idGrup = IN_idGrup;

  END CASE ;

END;

