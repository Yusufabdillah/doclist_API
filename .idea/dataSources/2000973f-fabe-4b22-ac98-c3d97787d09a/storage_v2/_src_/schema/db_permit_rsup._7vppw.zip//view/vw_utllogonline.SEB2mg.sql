create definer = root@localhost view vw_utllogonline as
select `db_permit_rsup`.`tbl_utllogonline`.`idLog`        AS `idLog`,
       `db_permit_rsup`.`tbl_utllogonline`.`idUser`       AS `idUser`,
       `db_permit_rsup`.`tbl_mstuser`.`namaUser`          AS `namaUser`,
       `db_permit_rsup`.`tbl_utllogonline`.`tanggalLog`   AS `tanggalLog`,
       `db_permit_rsup`.`tbl_utllogonline`.`signinLog`    AS `signinLog`,
       `db_permit_rsup`.`tbl_utllogonline`.`signoutLog`   AS `signoutLog`,
       `db_permit_rsup`.`tbl_utllogonline`.`hostnameLog`  AS `hostnameLog`,
       `db_permit_rsup`.`tbl_utllogonline`.`ipaddressLog` AS `ipaddressLog`,
       `db_permit_rsup`.`tbl_utllogonline`.`deviceLog`    AS `deviceLog`,
       `db_permit_rsup`.`tbl_utllogonline`.`browserLog`   AS `browserLog`,
       `db_permit_rsup`.`tbl_utllogonline`.`platformLog`  AS `platformLog`,
       `db_permit_rsup`.`tbl_utllogonline`.`useragentLog` AS `useragentLog`
from (`db_permit_rsup`.`tbl_utllogonline`
       left join `db_permit_rsup`.`tbl_mstuser`
                 on ((`db_permit_rsup`.`tbl_utllogonline`.`idUser` = `db_permit_rsup`.`tbl_mstuser`.`idUser`)))
order by `db_permit_rsup`.`tbl_utllogonline`.`idLog`;

