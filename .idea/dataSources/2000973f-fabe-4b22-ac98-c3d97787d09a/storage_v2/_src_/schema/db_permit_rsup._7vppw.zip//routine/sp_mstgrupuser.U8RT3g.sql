create
  definer = root@localhost procedure sp_mstgrupuser(IN KEY_CALL varchar(20), IN KOLOM varchar(40), IN IN_idGrup int,
                                                    IN IN_idAkses int, IN IN_idPerusahaan int,
                                                    IN IN_namaGrup varchar(50), IN CREATED_BY varchar(50),
                                                    IN UPDATED_BY varchar(50))
BEGIN

  CASE KEY_CALL
    WHEN 'getAll' THEN
    SELECT * FROM vw_mstgrupuser;

    WHEN 'getData' THEN
      CASE KOLOM
        WHEN 'idGrup' THEN
        SELECT * FROM vw_mstgrupuser WHERE idGrup = IN_idGrup;

        WHEN 'namaGrup' THEN
        SELECT * FROM vw_mstgrupuser WHERE namaGrup LIKE IN_namaGrup;
        END CASE ;

    WHEN 'create' THEN
      INSERT INTO tbl_mstgrupuser (idAkses, idPerusahaan, namaGrup, createdBy, createdDate)
                             VALUES (IN_idAkses, IN_idPerusahaan, IN_namaGrup, CREATED_BY, NOW());

    WHEN 'update' THEN
      UPDATE tbl_mstgrupuser SET
                                 idAkses = IN_idAkses,
                                 idPerusahaan = IN_idPerusahaan,
                                   namaGrup = IN_namaGrup,
                                   updatedBy = UPDATED_BY,
                                   updatedDate = now()
      WHERE idGrup = IN_idGrup;

    WHEN 'delete' THEN
      DELETE FROM tbl_mstgrupuser WHERE idGrup = IN_idGrup;

  END CASE ;

END;

