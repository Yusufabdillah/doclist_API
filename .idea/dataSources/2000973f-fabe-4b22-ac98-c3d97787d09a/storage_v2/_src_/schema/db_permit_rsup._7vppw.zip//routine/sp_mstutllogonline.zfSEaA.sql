create
  definer = root@localhost procedure sp_mstutllogonline(IN KEY_CALL varchar(20), IN KOLOM varchar(40), IN IN_idLog int,
                                                        IN IN_idUser varchar(50), IN IN_tanggalLog datetime,
                                                        IN IN_signinLog datetime, IN IN_signoutLog datetime,
                                                        IN IN_hostnameLog varchar(50), IN IN_ipaddressLog varchar(50),
                                                        IN IN_deviceLog varchar(50), IN IN_browserLog varchar(50),
                                                        IN IN_platformLog varchar(50), IN IN_useragentLog varchar(25))
BEGIN

  CASE KEY_CALL
    WHEN 'getAll' THEN
    SELECT * FROM vw_utllogonline;

    WHEN 'getData' THEN
      CASE KOLOM
        WHEN 'idLog' THEN
        SELECT * FROM vw_utllogonline WHERE idLog = IN_idLog;

        WHEN 'idUser' THEN
        SELECT * FROM vw_utllogonline WHERE idUser = IN_idUser;
        END CASE ;

    WHEN 'create' THEN
      INSERT INTO tbl_utllogonline (idUser, tanggalLog, signinLog, signoutLog, hostnameLog, ipaddressLog, deviceLog, browserLog, platformLog, useragentLog)
                             VALUES (IN_idUser, IN_tanggalLog, IN_signinLog, IN_signoutLog, IN_hostnameLog, IN_ipaddressLog, IN_deviceLog, IN_browserLog, IN_platformLog, IN_useragentLog);

    WHEN 'update' THEN
      UPDATE tbl_utllogonline SET signoutLog = IN_signoutLog WHERE idLog = IN_idLog;

    WHEN 'delete' THEN
      DELETE FROM tbl_utllogonline WHERE idLog = IN_idLog;

  END CASE ;

END;

