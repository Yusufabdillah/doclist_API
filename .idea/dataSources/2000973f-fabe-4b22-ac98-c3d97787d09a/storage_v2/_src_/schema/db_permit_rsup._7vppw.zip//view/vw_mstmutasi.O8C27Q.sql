create view vw_mstmutasi as
select `db_permit_rsup`.`tbl_mstmutasi`.`idMutasi`            AS `idMutasi`,
       `db_permit_rsup`.`tbl_mstmutasi`.`idDepartemen_asal`   AS `idDepartemen_asal`,
       `db_permit_rsup`.`tbl_mstdepartemen`.`namaDepartemen`  AS `namaDepartemen`,
       `db_permit_rsup`.`tbl_mstmutasi`.`idDepartemen_tujuan` AS `idDepartemen_tujuan`,
       `db_permit_rsup`.`tbl_mstmutasi`.`idDokumen`           AS `idDokumen`,
       `db_permit_rsup`.`tbl_mstdokumen`.`judulDokumen`       AS `judulDokumen`,
       `db_permit_rsup`.`tbl_mstdokumen`.`nomorDokumen`       AS `nomorDokumen`,
       `db_permit_rsup`.`tbl_mstmutasi`.`verifikasiMutasi`    AS `verifikasiMutasi`,
       `db_permit_rsup`.`tbl_mstmutasi`.`createdBy`           AS `createdBy`,
       `db_permit_rsup`.`tbl_mstmutasi`.`createdDate`         AS `createdDate`,
       `db_permit_rsup`.`tbl_mstmutasi`.`verifikasiBy`        AS `verifikasiBy`,
       `db_permit_rsup`.`tbl_mstmutasi`.`verifikasiDate`      AS `verifikasiDate`
from ((`db_permit_rsup`.`tbl_mstmutasi` left join `db_permit_rsup`.`tbl_mstdokumen` on ((
    `db_permit_rsup`.`tbl_mstmutasi`.`idDokumen` = `db_permit_rsup`.`tbl_mstdokumen`.`idDokumen`)))
       left join `db_permit_rsup`.`tbl_mstdepartemen` on ((`db_permit_rsup`.`tbl_mstmutasi`.`idDepartemen_asal` =
                                                           `db_permit_rsup`.`tbl_mstdepartemen`.`﻿idDepartemen`)));

