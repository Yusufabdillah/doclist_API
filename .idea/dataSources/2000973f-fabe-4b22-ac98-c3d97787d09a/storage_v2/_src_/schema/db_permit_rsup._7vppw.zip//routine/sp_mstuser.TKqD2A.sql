create
  definer = root@localhost procedure sp_mstuser(IN KEY_CALL varchar(20), IN KOLOM varchar(40), IN IN_idUser varchar(50),
                                                IN IN_idPerusahaan int, IN IN_idDepartemen int, IN IN_idJabatan int,
                                                IN IN_idGrup int, IN IN_namaUser varchar(100), IN IN_passUser text,
                                                IN IN_telpUser varchar(15), IN IN_statusUser tinyint(1),
                                                IN IN_statusAPI tinyint(1), IN IN_statusPIC tinyint(1),
                                                IN CREATED_BY varchar(50), IN UPDATED_BY varchar(50))
BEGIN

  CASE KEY_CALL
    WHEN 'getAll' THEN
    SELECT * FROM vw_mstuser;

    WHEN 'getData' THEN
      CASE KOLOM
        WHEN 'idUser' THEN
        SELECT * FROM vw_mstuser WHERE idUser = IN_idUser;

        WHEN 'idPerusahaan' THEN
        SELECT * FROM vw_mstuser WHERE idPerusahaan = IN_idPerusahaan;

        WHEN 'namaUser' THEN
        SELECT * FROM vw_mstuser WHERE namaUser LIKE IN_namaUser;
        END CASE ;

    WHEN 'create' THEN
      INSERT INTO tbl_mstuser (
                               idUser,
                               idPerusahaan,
                               idDepartemen,
                               idJabatan,
                               idGrup,
                               statusAPI,
                               statusPIC,
                               namaUser,
                               passUser,
                               statusUser,
                               telpUser,
                               createdBy,
                               createdDate
                               )
                             VALUES (
                                     IN_idUser,
                                     IN_idPerusahaan,
                                     IN_idDepartemen,
                                     IN_idJabatan,
                                     IN_idGrup,
                                     IN_statusAPI,
                                     IN_statusPIC,
                                     IN_namaUser,
                                     IN_passUser,
                                     IN_statusUser,
                                     IN_telpUser,
                                     CREATED_BY,
                                     NOW()
                                     );

    WHEN 'update' THEN
      UPDATE tbl_mstuser SET
                               idPerusahaan = IN_idPerusahaan,
                               idDepartemen = IN_idDepartemen,
                               idJabatan = IN_idJabatan,
                               idGrup = IN_idGrup,
                               statusAPI = IN_statusAPI,
                               statusPIC = IN_statusPIC,
                               namaUser = IN_namaUser,
                               passUser = IN_passUser,
                               statusUser = IN_statusUser,
                               telpUser = IN_telpUser,
                                   updatedBy = UPDATED_BY,
                                   updatedDate = now()
      WHERE idUser = IN_idUser;

    WHEN 'delete' THEN
      DELETE FROM tbl_mstuser WHERE idUser = IN_idUser;

    WHEN 'login' THEN
      SELECT * FROM vw_mstuser WHERE idUser = IN_idUser AND passUser = IN_passUser;

  END CASE ;

END;

