create definer = root@localhost view vw_mstperusahaan as
select `db_permit_rsup`.`tbl_mstperusahaan`.`idPerusahaan`        AS `idPerusahaan`,
       `db_permit_rsup`.`tbl_mstperusahaan`.`idKecamatan`         AS `idKecamatan`,
       `vw_mstkecamatan`.`namaKecamatan`                          AS `namaKecamatan`,
       `vw_mstkecamatan`.`kodeposKecamatan`                       AS `kodeposKecamatan`,
       `vw_mstkecamatan`.`idKota`                                 AS `idKota`,
       `vw_mstkecamatan`.`namaKota`                               AS `namaKota`,
       `vw_mstkecamatan`.`idProvinsi`                             AS `idProvinsi`,
       `vw_mstkecamatan`.`namaProvinsi`                           AS `namaProvinsi`,
       `vw_mstkecamatan`.`idNegara`                               AS `idNegara`,
       `vw_mstkecamatan`.`namaNegara`                             AS `namaNegara`,
       `db_permit_rsup`.`tbl_mstperusahaan`.`lokasiPerusahaan`    AS `lokasiPerusahaan`,
       `db_permit_rsup`.`tbl_mstperusahaan`.`namaPerusahaan`      AS `namaPerusahaan`,
       `db_permit_rsup`.`tbl_mstperusahaan`.`singkatanPerusahaan` AS `singkatanPerusahaan`,
       `db_permit_rsup`.`tbl_mstperusahaan`.`createdBy`           AS `createdBy`,
       `db_permit_rsup`.`tbl_mstperusahaan`.`createdDate`         AS `createdDate`,
       `db_permit_rsup`.`tbl_mstperusahaan`.`updatedBy`           AS `updatedBy`,
       `db_permit_rsup`.`tbl_mstperusahaan`.`updatedDate`         AS `updatedDate`
from (`db_permit_rsup`.`tbl_mstperusahaan`
       left join `db_permit_rsup`.`vw_mstkecamatan`
                 on ((`db_permit_rsup`.`tbl_mstperusahaan`.`idKecamatan` = `vw_mstkecamatan`.`idKecamatan`)));

